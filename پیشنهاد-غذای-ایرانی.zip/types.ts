
export interface Food {
  name: string;
  description: string;
  type: 'صبحانه' | 'ناهار' | 'شام' | 'دسر' | 'نوشیدنی';
}
